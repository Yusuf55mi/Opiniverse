import '/auth/supabase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'home_page_model.dart';
export 'home_page_model.dart';

class HomePageWidget extends StatefulWidget {
  const HomePageWidget({super.key});

  @override
  State<HomePageWidget> createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget>
    with TickerProviderStateMixin {
  late HomePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomePageModel());

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();

    animationsMap.addAll({
      'containerOnPageLoadAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 300.ms),
          MoveEffect(
            curve: Curves.bounceOut,
            delay: 300.0.ms,
            duration: 400.0.ms,
            begin: Offset(0.0, 100.0),
            end: Offset(0.0, 0.0),
          ),
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 300.0.ms,
            duration: 400.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'containerOnPageLoadAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 300.ms),
          MoveEffect(
            curve: Curves.bounceOut,
            delay: 300.0.ms,
            duration: 400.0.ms,
            begin: Offset(0.0, 100.0),
            end: Offset(0.0, 0.0),
          ),
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 300.0.ms,
            duration: 400.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        drawer: Container(
          width: 230.0,
          child: Drawer(
            elevation: 16.0,
            child: Container(
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).primaryBackground,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
                    child: Text(
                      'Opiniverse',
                      style: FlutterFlowTheme.of(context).titleLarge.override(
                            fontFamily: 'Inter',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 1.0, 0.0, 100.0),
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(),
                      child: Padding(
                        padding: EdgeInsets.all(12.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Align(
                              alignment: AlignmentDirectional(0.0, 0.0),
                              child: Container(
                                width: 100.0,
                                height: 100.0,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      FlutterFlowTheme.of(context).primary,
                                      FlutterFlowTheme.of(context).secondary
                                    ],
                                    stops: [0.0, 1.0],
                                    begin: AlignmentDirectional(0.0, -1.0),
                                    end: AlignmentDirectional(0, 1.0),
                                  ),
                                  shape: BoxShape.circle,
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(2.0),
                                  child: FutureBuilder<List<FilepathsRow>>(
                                    future: FilepathsTable().querySingleRow(
                                      queryFn: (q) => q.eq(
                                        'content_id',
                                        currentUserUid,
                                      ),
                                    ),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 50.0,
                                            height: 50.0,
                                            child: CircularProgressIndicator(
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                FlutterFlowTheme.of(context)
                                                    .primary,
                                              ),
                                            ),
                                          ),
                                        );
                                      }
                                      List<FilepathsRow>
                                          circleImageFilepathsRowList =
                                          snapshot.data!;

                                      final circleImageFilepathsRow =
                                          circleImageFilepathsRowList.isNotEmpty
                                              ? circleImageFilepathsRowList
                                                  .first
                                              : null;

                                      return InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          context.pushNamed(
                                            'ProfilePage',
                                            extra: <String, dynamic>{
                                              kTransitionInfoKey:
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                                duration:
                                                    Duration(milliseconds: 0),
                                              ),
                                            },
                                          );
                                        },
                                        child: Container(
                                          width: 90.0,
                                          height: 90.0,
                                          clipBehavior: Clip.antiAlias,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                          ),
                                          child: CachedNetworkImage(
                                            fadeInDuration:
                                                Duration(milliseconds: 500),
                                            fadeOutDuration:
                                                Duration(milliseconds: 500),
                                            imageUrl: valueOrDefault<String>(
                                              circleImageFilepathsRow?.filePath,
                                              'https://zkqziwlckfserjysczus.supabase.co/storage/v1/object/public/Opiniverse/ProfilePic/Ekran%20Resmi%202024-07-25%2010.43.01.png',
                                            ),
                                            fit: BoxFit.fitWidth,
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                            Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                FutureBuilder<List<UserInfosRow>>(
                                  future: UserInfosTable().querySingleRow(
                                    queryFn: (q) => q.eq(
                                      'user_id',
                                      currentUserUid,
                                    ),
                                  ),
                                  builder: (context, snapshot) {
                                    // Customize what your widget looks like when it's loading.
                                    if (!snapshot.hasData) {
                                      return Center(
                                        child: SizedBox(
                                          width: 50.0,
                                          height: 50.0,
                                          child: CircularProgressIndicator(
                                            valueColor:
                                                AlwaysStoppedAnimation<Color>(
                                              FlutterFlowTheme.of(context)
                                                  .primary,
                                            ),
                                          ),
                                        ),
                                      );
                                    }
                                    List<UserInfosRow> textUserInfosRowList =
                                        snapshot.data!;

                                    final textUserInfosRow =
                                        textUserInfosRowList.isNotEmpty
                                            ? textUserInfosRowList.first
                                            : null;

                                    return Text(
                                      '-${textUserInfosRow?.nickName}',
                                      style: FlutterFlowTheme.of(context)
                                          .headlineSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    );
                                  },
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 4.0, 0.0, 0.0),
                                  child: Text(
                                    currentUserEmail,
                                    style: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 55.0, 0.0, 25.0),
                    child: Container(
                      width: 225.0,
                      height: 200.0,
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed(
                                'editProfile',
                                extra: <String, dynamic>{
                                  kTransitionInfoKey: TransitionInfo(
                                    hasTransition: true,
                                    transitionType: PageTransitionType.fade,
                                    duration: Duration(milliseconds: 0),
                                  ),
                                },
                              );
                            },
                            child: Card(
                              clipBehavior: Clip.antiAliasWithSaveLayer,
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              elevation: 4.0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(6.0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 5.0, 0.0),
                                      child: Text(
                                        'Edit Profile',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Inter',
                                              fontSize: 22.0,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                    ),
                                    Icon(
                                      Icons.edit,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 25.0,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed(
                                'PostedTopics',
                                extra: <String, dynamic>{
                                  kTransitionInfoKey: TransitionInfo(
                                    hasTransition: true,
                                    transitionType: PageTransitionType.fade,
                                    duration: Duration(milliseconds: 0),
                                  ),
                                },
                              );
                            },
                            child: Card(
                              clipBehavior: Clip.antiAliasWithSaveLayer,
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              elevation: 4.0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(6.0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 5.0, 0.0),
                                      child: Text(
                                        'Edit Topics',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Inter',
                                              fontSize: 22.0,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                    ),
                                    Icon(
                                      Icons.edit,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 25.0,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed(
                                'PostedComments',
                                extra: <String, dynamic>{
                                  kTransitionInfoKey: TransitionInfo(
                                    hasTransition: true,
                                    transitionType: PageTransitionType.fade,
                                    duration: Duration(milliseconds: 0),
                                  ),
                                },
                              );
                            },
                            child: Card(
                              clipBehavior: Clip.antiAliasWithSaveLayer,
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              elevation: 4.0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(6.0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 5.0, 0.0),
                                      child: Text(
                                        'Edit Comments',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Inter',
                                              fontSize: 22.0,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                    ),
                                    Icon(
                                      Icons.edit,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 25.0,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed(
                                'PostedComments',
                                extra: <String, dynamic>{
                                  kTransitionInfoKey: TransitionInfo(
                                    hasTransition: true,
                                    transitionType: PageTransitionType.fade,
                                    duration: Duration(milliseconds: 0),
                                  ),
                                },
                              );
                            },
                            child: Card(
                              clipBehavior: Clip.antiAliasWithSaveLayer,
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              elevation: 4.0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(6.0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 5.0, 0.0),
                                      child: Text(
                                        'Search Topics',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Inter',
                                              fontSize: 22.0,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                    ),
                                    Icon(
                                      Icons.search_sharp,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 25.0,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () async {
                      context.pushNamed(
                        'FeedbackPage',
                        extra: <String, dynamic>{
                          kTransitionInfoKey: TransitionInfo(
                            hasTransition: true,
                            transitionType: PageTransitionType.fade,
                            duration: Duration(milliseconds: 0),
                          ),
                        },
                      );
                    },
                    child: Card(
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                      elevation: 4.0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(6.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 5.0, 0.0),
                              child: Text(
                                'Support',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      fontSize: 22.0,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ),
                            FaIcon(
                              FontAwesomeIcons.questionCircle,
                              color: FlutterFlowTheme.of(context).secondaryText,
                              size: 24.0,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Card(
                    clipBehavior: Clip.antiAliasWithSaveLayer,
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                    elevation: 4.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(6.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 5.0, 0.0),
                            child: Text(
                              'Terms of Service',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    fontSize: 22.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                          Icon(
                            Icons.privacy_tip_rounded,
                            color: FlutterFlowTheme.of(context).secondaryText,
                            size: 24.0,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Card(
                    clipBehavior: Clip.antiAliasWithSaveLayer,
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                    elevation: 4.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(6.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 5.0, 0.0),
                            child: Text(
                              'Invite Friends',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    fontSize: 22.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                          Icon(
                            Icons.ios_share_outlined,
                            color: FlutterFlowTheme.of(context).secondaryText,
                            size: 24.0,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        body: NestedScrollView(
          floatHeaderSlivers: true,
          headerSliverBuilder: (context, _) => [
            if (responsiveVisibility(
              context: context,
              desktop: false,
            ))
              SliverAppBar(
                pinned: false,
                floating: false,
                backgroundColor: Color(0xFF508358),
                automaticallyImplyLeading: false,
                leading: FlutterFlowIconButton(
                  borderColor: Colors.transparent,
                  borderRadius: 30.0,
                  borderWidth: 1.0,
                  buttonSize: 60.0,
                  icon: Icon(
                    Icons.view_list,
                    color: Colors.white,
                    size: 30.0,
                  ),
                  onPressed: () async {
                    scaffoldKey.currentState!.openDrawer();
                  },
                ),
                actions: [],
                flexibleSpace: FlexibleSpaceBar(
                  title: Text(
                    'Topics',
                    style: FlutterFlowTheme.of(context).headlineMedium.override(
                          fontFamily: 'Readex Pro',
                          color: Colors.white,
                          fontSize: 28.0,
                          letterSpacing: 0.0,
                        ),
                  ),
                  centerTitle: true,
                  expandedTitleScale: 1.0,
                ),
                elevation: 2.0,
              )
          ],
          body: Builder(
            builder: (context) {
              return Container(
                width: double.infinity,
                height: MediaQuery.sizeOf(context).width < 991.0
                    ? (MediaQuery.sizeOf(context).height * 0.7)
                    : MediaQuery.sizeOf(context).height,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (MediaQuery.sizeOf(context).width >= 991.0)
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.05,
                            height: MediaQuery.sizeOf(context).height * 1.0,
                            constraints: BoxConstraints(
                              maxWidth: 75.0,
                            ),
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).alternate,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 13.0, 0.0, 0.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      scaffoldKey.currentState!.openDrawer();
                                    },
                                    child: Icon(
                                      Icons.view_list,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 30.0,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      context.pushNamed(
                                        'FavoritesPage',
                                        extra: <String, dynamic>{
                                          kTransitionInfoKey: TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                            duration: Duration(milliseconds: 0),
                                          ),
                                        },
                                      );
                                    },
                                    child: Icon(
                                      Icons.favorite_sharp,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 30.0,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      context.pushNamed(
                                        'SearchPage',
                                        extra: <String, dynamic>{
                                          kTransitionInfoKey: TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                            duration: Duration(milliseconds: 0),
                                          ),
                                        },
                                      );
                                    },
                                    child: Icon(
                                      Icons.search_rounded,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 30.0,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      context.pushNamed(
                                        'CreateTopic',
                                        extra: <String, dynamic>{
                                          kTransitionInfoKey: TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                            duration: Duration(milliseconds: 0),
                                          ),
                                        },
                                      );
                                    },
                                    child: Icon(
                                      Icons.add_circle,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 30.0,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      context.pushNamed(
                                        'upvotes',
                                        extra: <String, dynamic>{
                                          kTransitionInfoKey: TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                            duration: Duration(milliseconds: 0),
                                          ),
                                        },
                                      );
                                    },
                                    child: Icon(
                                      Icons.arrow_circle_up,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 30.0,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      context.pushNamed(
                                        'ProfilePage',
                                        extra: <String, dynamic>{
                                          kTransitionInfoKey: TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                            duration: Duration(milliseconds: 0),
                                          ),
                                        },
                                      );
                                    },
                                    child: Icon(
                                      Icons.person,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      size: 30.0,
                                    ),
                                  ),
                                ),
                              ].divide(SizedBox(height: 16.0)),
                            ),
                          ),
                        Expanded(
                          child: Container(
                            width: MediaQuery.sizeOf(context).width >= 991.0
                                ? (MediaQuery.sizeOf(context).width * 0.95)
                                : MediaQuery.sizeOf(context).width,
                            height: MediaQuery.sizeOf(context).width < 991.0
                                ? (MediaQuery.sizeOf(context).height * 0.85)
                                : MediaQuery.sizeOf(context).height,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: Align(
                              alignment: AlignmentDirectional(0.0, -1.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      if (MediaQuery.sizeOf(context).width >=
                                          991.0)
                                        Align(
                                          alignment:
                                              AlignmentDirectional(-1.0, -1.0),
                                          child: Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 0.0, 12.0),
                                            child: Container(
                                              width: MediaQuery.sizeOf(context)
                                                      .width *
                                                  0.95,
                                              height: MediaQuery.sizeOf(context)
                                                      .height *
                                                  0.07,
                                              constraints: BoxConstraints(
                                                maxHeight: 70.0,
                                              ),
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .alternate,
                                              ),
                                              child: Align(
                                                alignment: AlignmentDirectional(
                                                    0.0, 0.0),
                                                child: Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0.0, 0.0),
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    66.0,
                                                                    0.0),
                                                        child: Text(
                                                          'Home',
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .titleLarge
                                                              .override(
                                                                fontFamily:
                                                                    'Inter',
                                                                fontSize: 28.0,
                                                                letterSpacing:
                                                                    0.0,
                                                              ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      Expanded(
                                        child: Container(
                                          width: MediaQuery.sizeOf(context)
                                                      .width <
                                                  991.0
                                              ? MediaQuery.sizeOf(context).width
                                              : (MediaQuery.sizeOf(context)
                                                      .width *
                                                  0.95),
                                          height:
                                              MediaQuery.sizeOf(context)
                                                          .width <
                                                      991.0
                                                  ? (MediaQuery.sizeOf(context)
                                                          .height *
                                                      0.85)
                                                  : (MediaQuery.sizeOf(context)
                                                          .height *
                                                      0.93),
                                          constraints: BoxConstraints(
                                            maxHeight: 900.0,
                                          ),
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          12.0, 0.0, 0.0, 0.0),
                                                  child: FutureBuilder<
                                                      List<TopicsRow>>(
                                                    future: (_model
                                                                .requestCompleter ??=
                                                            Completer<
                                                                List<
                                                                    TopicsRow>>()
                                                              ..complete(
                                                                  TopicsTable()
                                                                      .queryRows(
                                                                queryFn: (q) =>
                                                                    q.order(
                                                                        'upvotes'),
                                                              )))
                                                        .future,
                                                    builder:
                                                        (context, snapshot) {
                                                      // Customize what your widget looks like when it's loading.
                                                      if (!snapshot.hasData) {
                                                        return Center(
                                                          child: SizedBox(
                                                            width: 50.0,
                                                            height: 50.0,
                                                            child:
                                                                CircularProgressIndicator(
                                                              valueColor:
                                                                  AlwaysStoppedAnimation<
                                                                      Color>(
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .primary,
                                                              ),
                                                            ),
                                                          ),
                                                        );
                                                      }
                                                      List<TopicsRow>
                                                          listViewTopicsRowList =
                                                          snapshot.data!;

                                                      return ListView.builder(
                                                        padding:
                                                            EdgeInsets.zero,
                                                        primary: false,
                                                        shrinkWrap: true,
                                                        scrollDirection:
                                                            Axis.vertical,
                                                        itemCount:
                                                            listViewTopicsRowList
                                                                .length,
                                                        itemBuilder: (context,
                                                            listViewIndex) {
                                                          final listViewTopicsRow =
                                                              listViewTopicsRowList[
                                                                  listViewIndex];
                                                          return Padding(
                                                            padding:
                                                                EdgeInsets.all(
                                                                    4.0),
                                                            child: Container(
                                                              width: 100.0,
                                                              height: 100.0,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondaryBackground,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8.0),
                                                              ),
                                                              child: InkWell(
                                                                splashColor: Colors
                                                                    .transparent,
                                                                focusColor: Colors
                                                                    .transparent,
                                                                hoverColor: Colors
                                                                    .transparent,
                                                                highlightColor:
                                                                    Colors
                                                                        .transparent,
                                                                onTap:
                                                                    () async {
                                                                  context
                                                                      .pushNamed(
                                                                    'TopicsPage',
                                                                    queryParameters:
                                                                        {
                                                                      'topicId':
                                                                          serializeParam(
                                                                        listViewTopicsRow
                                                                            .id,
                                                                        ParamType
                                                                            .String,
                                                                      ),
                                                                    }.withoutNulls,
                                                                    extra: <String,
                                                                        dynamic>{
                                                                      kTransitionInfoKey:
                                                                          TransitionInfo(
                                                                        hasTransition:
                                                                            true,
                                                                        transitionType:
                                                                            PageTransitionType.fade,
                                                                        duration:
                                                                            Duration(milliseconds: 0),
                                                                      ),
                                                                    },
                                                                  );
                                                                },
                                                                child: Card(
                                                                  clipBehavior:
                                                                      Clip.antiAliasWithSaveLayer,
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .primaryBackground,
                                                                  elevation:
                                                                      4.0,
                                                                  shape:
                                                                      RoundedRectangleBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            8.0),
                                                                  ),
                                                                  child: Row(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .max,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      Expanded(
                                                                        child:
                                                                            Stack(
                                                                          children: [
                                                                            Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(8.0, 10.0, 0.0, 0.0),
                                                                              child: Text(
                                                                                listViewTopicsRow.title,
                                                                                style: FlutterFlowTheme.of(context).titleLarge.override(
                                                                                      fontFamily: 'Inter',
                                                                                      fontSize: MediaQuery.sizeOf(context).width < 991.0 ? 16.0 : 20.0,
                                                                                      letterSpacing: 0.0,
                                                                                    ),
                                                                              ),
                                                                            ),
                                                                            Align(
                                                                              alignment: AlignmentDirectional(1.0, 1.0),
                                                                              child: Padding(
                                                                                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
                                                                                child: FutureBuilder<List<VotesRow>>(
                                                                                  future: VotesTable().queryRows(
                                                                                    queryFn: (q) => q.eq(
                                                                                      'topic_id',
                                                                                      listViewTopicsRow.id,
                                                                                    ),
                                                                                  ),
                                                                                  builder: (context, snapshot) {
                                                                                    // Customize what your widget looks like when it's loading.
                                                                                    if (!snapshot.hasData) {
                                                                                      return Center(
                                                                                        child: SizedBox(
                                                                                          width: 50.0,
                                                                                          height: 50.0,
                                                                                          child: CircularProgressIndicator(
                                                                                            valueColor: AlwaysStoppedAnimation<Color>(
                                                                                              FlutterFlowTheme.of(context).primary,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      );
                                                                                    }
                                                                                    List<VotesRow> textVotesRowList = snapshot.data!;

                                                                                    return Text(
                                                                                      'Upvotes: ${textVotesRowList.length.toString()}',
                                                                                      style: FlutterFlowTheme.of(context).labelLarge.override(
                                                                                            fontFamily: 'Inter',
                                                                                            fontSize: 12.0,
                                                                                            letterSpacing: 0.0,
                                                                                          ),
                                                                                    );
                                                                                  },
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                      Stack(
                                                                        children: [
                                                                          FutureBuilder<
                                                                              List<FavoritesRow>>(
                                                                            future:
                                                                                FavoritesTable().querySingleRow(
                                                                              queryFn: (q) => q
                                                                                  .eq(
                                                                                    'user_id',
                                                                                    currentUserUid,
                                                                                  )
                                                                                  .eq(
                                                                                    'topic_id',
                                                                                    listViewTopicsRow.id,
                                                                                  ),
                                                                            ),
                                                                            builder:
                                                                                (context, snapshot) {
                                                                              // Customize what your widget looks like when it's loading.
                                                                              if (!snapshot.hasData) {
                                                                                return Center(
                                                                                  child: SizedBox(
                                                                                    width: 50.0,
                                                                                    height: 50.0,
                                                                                    child: CircularProgressIndicator(
                                                                                      valueColor: AlwaysStoppedAnimation<Color>(
                                                                                        FlutterFlowTheme.of(context).primary,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }
                                                                              List<FavoritesRow> columnFavoritesRowList = snapshot.data!;

                                                                              final columnFavoritesRow = columnFavoritesRowList.isNotEmpty ? columnFavoritesRowList.first : null;

                                                                              return Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                children: [
                                                                                  FutureBuilder<List<VotesRow>>(
                                                                                    future: VotesTable().querySingleRow(
                                                                                      queryFn: (q) => q
                                                                                          .eq(
                                                                                            'user_id',
                                                                                            currentUserUid,
                                                                                          )
                                                                                          .eq(
                                                                                            'topic_id',
                                                                                            listViewTopicsRow.id,
                                                                                          ),
                                                                                    ),
                                                                                    builder: (context, snapshot) {
                                                                                      // Customize what your widget looks like when it's loading.
                                                                                      if (!snapshot.hasData) {
                                                                                        return Center(
                                                                                          child: SizedBox(
                                                                                            width: 50.0,
                                                                                            height: 50.0,
                                                                                            child: CircularProgressIndicator(
                                                                                              valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                FlutterFlowTheme.of(context).primary,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      }
                                                                                      List<VotesRow> conditionalBuilderVotesRowList = snapshot.data!;

                                                                                      final conditionalBuilderVotesRow = conditionalBuilderVotesRowList.isNotEmpty ? conditionalBuilderVotesRowList.first : null;

                                                                                      return Builder(
                                                                                        builder: (context) {
                                                                                          if (conditionalBuilderVotesRow?.id != null && conditionalBuilderVotesRow?.id != '') {
                                                                                            return Padding(
                                                                                              padding: EdgeInsets.all(2.0),
                                                                                              child: InkWell(
                                                                                                splashColor: Colors.transparent,
                                                                                                focusColor: Colors.transparent,
                                                                                                hoverColor: Colors.transparent,
                                                                                                highlightColor: Colors.transparent,
                                                                                                onTap: () async {
                                                                                                  await VotesTable().delete(
                                                                                                    matchingRows: (rows) => rows
                                                                                                        .eq(
                                                                                                          'user_id',
                                                                                                          currentUserUid,
                                                                                                        )
                                                                                                        .eq(
                                                                                                          'topic_id',
                                                                                                          listViewTopicsRow.id,
                                                                                                        ),
                                                                                                  );
                                                                                                  await Future.delayed(const Duration(milliseconds: 100));
                                                                                                  safeSetState(() => _model.requestCompleter = null);
                                                                                                },
                                                                                                child: Icon(
                                                                                                  Icons.arrow_circle_up,
                                                                                                  color: FlutterFlowTheme.of(context).secondary,
                                                                                                  size: 40.0,
                                                                                                ),
                                                                                              ),
                                                                                            );
                                                                                          } else {
                                                                                            return FutureBuilder<List<UserInfosRow>>(
                                                                                              future: UserInfosTable().querySingleRow(
                                                                                                queryFn: (q) => q.eq(
                                                                                                  'user_id',
                                                                                                  currentUserUid,
                                                                                                ),
                                                                                              ),
                                                                                              builder: (context, snapshot) {
                                                                                                // Customize what your widget looks like when it's loading.
                                                                                                if (!snapshot.hasData) {
                                                                                                  return Center(
                                                                                                    child: SizedBox(
                                                                                                      width: 50.0,
                                                                                                      height: 50.0,
                                                                                                      child: CircularProgressIndicator(
                                                                                                        valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                          FlutterFlowTheme.of(context).primary,
                                                                                                        ),
                                                                                                      ),
                                                                                                    ),
                                                                                                  );
                                                                                                }
                                                                                                List<UserInfosRow> iconUserInfosRowList = snapshot.data!;

                                                                                                final iconUserInfosRow = iconUserInfosRowList.isNotEmpty ? iconUserInfosRowList.first : null;

                                                                                                return InkWell(
                                                                                                  splashColor: Colors.transparent,
                                                                                                  focusColor: Colors.transparent,
                                                                                                  hoverColor: Colors.transparent,
                                                                                                  highlightColor: Colors.transparent,
                                                                                                  onTap: () async {
                                                                                                    await VotesTable().insert({
                                                                                                      'user_id': currentUserUid,
                                                                                                      'topic_id': listViewTopicsRow.id,
                                                                                                      'created_at': supaSerialize<DateTime>(getCurrentTimestamp),
                                                                                                    });
                                                                                                    if (iconUserInfosRow?.userId != null && iconUserInfosRow?.userId != '') {
                                                                                                      await Future.delayed(const Duration(milliseconds: 100));
                                                                                                    } else {
                                                                                                      await showDialog(
                                                                                                        context: context,
                                                                                                        builder: (alertDialogContext) {
                                                                                                          return AlertDialog(
                                                                                                            title: Text('Uncompleted Profile!'),
                                                                                                            content: Text('Please complete your profile to use app functions.'),
                                                                                                            actions: [
                                                                                                              TextButton(
                                                                                                                onPressed: () => Navigator.pop(alertDialogContext),
                                                                                                                child: Text('Ok'),
                                                                                                              ),
                                                                                                            ],
                                                                                                          );
                                                                                                        },
                                                                                                      );

                                                                                                      context.pushNamed('ProfilePage');
                                                                                                    }

                                                                                                    safeSetState(() => _model.requestCompleter = null);
                                                                                                  },
                                                                                                  child: Icon(
                                                                                                    Icons.arrow_circle_up,
                                                                                                    color: FlutterFlowTheme.of(context).secondaryText,
                                                                                                    size: 40.0,
                                                                                                  ),
                                                                                                );
                                                                                              },
                                                                                            );
                                                                                          }
                                                                                        },
                                                                                      );
                                                                                    },
                                                                                  ),
                                                                                  Builder(
                                                                                    builder: (context) {
                                                                                      if (columnFavoritesRow?.id != null && columnFavoritesRow?.id != '') {
                                                                                        return Padding(
                                                                                          padding: EdgeInsets.all(2.0),
                                                                                          child: InkWell(
                                                                                            splashColor: Colors.transparent,
                                                                                            focusColor: Colors.transparent,
                                                                                            hoverColor: Colors.transparent,
                                                                                            highlightColor: Colors.transparent,
                                                                                            onTap: () async {
                                                                                              await FavoritesTable().delete(
                                                                                                matchingRows: (rows) => rows
                                                                                                    .eq(
                                                                                                      'user_id',
                                                                                                      currentUserUid,
                                                                                                    )
                                                                                                    .eq(
                                                                                                      'topic_id',
                                                                                                      listViewTopicsRow.id,
                                                                                                    ),
                                                                                              );
                                                                                              await Future.delayed(const Duration(milliseconds: 100));
                                                                                              safeSetState(() => _model.requestCompleter = null);
                                                                                            },
                                                                                            child: Icon(
                                                                                              Icons.favorite_border,
                                                                                              color: FlutterFlowTheme.of(context).error,
                                                                                              size: 40.0,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      } else {
                                                                                        return InkWell(
                                                                                          splashColor: Colors.transparent,
                                                                                          focusColor: Colors.transparent,
                                                                                          hoverColor: Colors.transparent,
                                                                                          highlightColor: Colors.transparent,
                                                                                          onTap: () async {
                                                                                            await FavoritesTable().insert({
                                                                                              'user_id': currentUserUid,
                                                                                              'topic_id': listViewTopicsRow.id,
                                                                                              'created_at': supaSerialize<DateTime>(getCurrentTimestamp),
                                                                                            });
                                                                                            await Future.delayed(const Duration(milliseconds: 100));
                                                                                            safeSetState(() => _model.requestCompleter = null);
                                                                                          },
                                                                                          child: Icon(
                                                                                            Icons.favorite_border,
                                                                                            color: FlutterFlowTheme.of(context).secondaryText,
                                                                                            size: 40.0,
                                                                                          ),
                                                                                        );
                                                                                      }
                                                                                    },
                                                                                  ),
                                                                                ],
                                                                              );
                                                                            },
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          );
                                                        },
                                                      );
                                                    },
                                                  ),
                                                ),
                                              ),
                                              Column(
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  if ((MediaQuery.sizeOf(
                                                                  context)
                                                              .width >=
                                                          991.0) &&
                                                      responsiveVisibility(
                                                        context: context,
                                                        phone: false,
                                                      ))
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              1.0, -1.0),
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    12.0,
                                                                    5.0,
                                                                    0.0,
                                                                    0.0),
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      0.0),
                                                          child: BackdropFilter(
                                                            filter: ImageFilter
                                                                .blur(
                                                              sigmaX: 2.0,
                                                              sigmaY: 2.0,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          2.0,
                                                                          15.0,
                                                                          0.0),
                                                              child: Container(
                                                                width: 455.0,
                                                                height: _model.searchText !=
                                                                            null &&
                                                                        _model.searchText !=
                                                                            ''
                                                                    ? 455.0
                                                                    : 70.0,
                                                                constraints:
                                                                    BoxConstraints(
                                                                  maxWidth:
                                                                      770.0,
                                                                ),
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .accent1,
                                                                  boxShadow: [
                                                                    BoxShadow(
                                                                      blurRadius:
                                                                          12.0,
                                                                      color: Color(
                                                                          0x1E000000),
                                                                      offset:
                                                                          Offset(
                                                                        0.0,
                                                                        5.0,
                                                                      ),
                                                                    )
                                                                  ],
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              16.0),
                                                                ),
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          8.0,
                                                                          0.0,
                                                                          0.0),
                                                                      child:
                                                                          Container(
                                                                        height:
                                                                            55.0,
                                                                        child:
                                                                            Stack(
                                                                          children: [
                                                                            if ((MediaQuery.sizeOf(context).width >= 991.0) &&
                                                                                responsiveVisibility(
                                                                                  context: context,
                                                                                  phone: false,
                                                                                ))
                                                                              Align(
                                                                                alignment: AlignmentDirectional(-1.0, 0.0),
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 0.0, 0.0),
                                                                                  child: TextFormField(
                                                                                    controller: _model.textController,
                                                                                    focusNode: _model.textFieldFocusNode,
                                                                                    onFieldSubmitted: (_) async {
                                                                                      FFAppState().searchText = _model.textController.text;
                                                                                      safeSetState(() {});
                                                                                      _model.searchText = _model.textController.text;
                                                                                      safeSetState(() {});
                                                                                      _model.apiResult4wu = await SearchOnTopicsCall.call(
                                                                                        searchTerm: FFAppState().searchText,
                                                                                      );

                                                                                      safeSetState(() {});
                                                                                    },
                                                                                    autofocus: true,
                                                                                    obscureText: false,
                                                                                    decoration: InputDecoration(
                                                                                      labelText: 'Search topics...',
                                                                                      hintStyle: FlutterFlowTheme.of(context).titleMedium.override(
                                                                                            fontFamily: 'Inter',
                                                                                            color: FlutterFlowTheme.of(context).secondaryText,
                                                                                            letterSpacing: 0.0,
                                                                                          ),
                                                                                      enabledBorder: InputBorder.none,
                                                                                      focusedBorder: InputBorder.none,
                                                                                      errorBorder: InputBorder.none,
                                                                                      focusedErrorBorder: InputBorder.none,
                                                                                      contentPadding: EdgeInsetsDirectional.fromSTEB(24.0, 32.0, 0.0, 32.0),
                                                                                    ),
                                                                                    style: FlutterFlowTheme.of(context).titleMedium.override(
                                                                                          fontFamily: 'Inter',
                                                                                          letterSpacing: 0.0,
                                                                                        ),
                                                                                    validator: _model.textControllerValidator.asValidator(context),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            Align(
                                                                              alignment: AlignmentDirectional(1.0, 0.0),
                                                                              child: Padding(
                                                                                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 16.0, 0.0),
                                                                                child: FFButtonWidget(
                                                                                  onPressed: () async {
                                                                                    FFAppState().searchText = _model.textController.text;
                                                                                    safeSetState(() {});
                                                                                    _model.searchText = _model.textController.text;
                                                                                    safeSetState(() {});
                                                                                    _model.apiResult4w4 = await SearchOnTopicsCall.call(
                                                                                      searchTerm: FFAppState().searchText,
                                                                                    );

                                                                                    safeSetState(() {});
                                                                                  },
                                                                                  text: 'Search',
                                                                                  options: FFButtonOptions(
                                                                                    width: 90.0,
                                                                                    height: 40.0,
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                    iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                    color: FlutterFlowTheme.of(context).secondary,
                                                                                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                          fontFamily: 'Inter',
                                                                                          color: Colors.white,
                                                                                          fontSize: 14.0,
                                                                                          letterSpacing: 0.0,
                                                                                        ),
                                                                                    elevation: 2.0,
                                                                                    borderSide: BorderSide(
                                                                                      color: Colors.transparent,
                                                                                      width: 1.0,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(40.0),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    if ((_model.searchText !=
                                                                                null &&
                                                                            _model.searchText !=
                                                                                '') &&
                                                                        responsiveVisibility(
                                                                          context:
                                                                              context,
                                                                          phone:
                                                                              false,
                                                                        ))
                                                                      Expanded(
                                                                        child:
                                                                            Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              1.0),
                                                                          child:
                                                                              ClipRRect(
                                                                            borderRadius:
                                                                                BorderRadius.only(
                                                                              bottomLeft: Radius.circular(15.0),
                                                                              bottomRight: Radius.circular(15.0),
                                                                              topLeft: Radius.circular(0.0),
                                                                              topRight: Radius.circular(0.0),
                                                                            ),
                                                                            child:
                                                                                Container(
                                                                              width: double.infinity,
                                                                              height: 505.0,
                                                                              decoration: BoxDecoration(
                                                                                color: FlutterFlowTheme.of(context).secondaryBackground,
                                                                                borderRadius: BorderRadius.only(
                                                                                  bottomLeft: Radius.circular(15.0),
                                                                                  bottomRight: Radius.circular(15.0),
                                                                                  topLeft: Radius.circular(0.0),
                                                                                  topRight: Radius.circular(0.0),
                                                                                ),
                                                                              ),
                                                                              child: SingleChildScrollView(
                                                                                child: Column(
                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                  children: [
                                                                                    FutureBuilder<ApiCallResponse>(
                                                                                      future: (_model.apiRequestCompleter1 ??= Completer<ApiCallResponse>()
                                                                                            ..complete(SearchOnTopicsCall.call(
                                                                                              searchTerm: FFAppState().searchText,
                                                                                            )))
                                                                                          .future,
                                                                                      builder: (context, snapshot) {
                                                                                        // Customize what your widget looks like when it's loading.
                                                                                        if (!snapshot.hasData) {
                                                                                          return Center(
                                                                                            child: SizedBox(
                                                                                              width: 50.0,
                                                                                              height: 50.0,
                                                                                              child: CircularProgressIndicator(
                                                                                                valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                  FlutterFlowTheme.of(context).primary,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          );
                                                                                        }
                                                                                        final listViewSearchOnTopicsResponse = snapshot.data!;

                                                                                        return Builder(
                                                                                          builder: (context) {
                                                                                            final topicid = SearchOnTopicsCall.topicid(
                                                                                                  listViewSearchOnTopicsResponse.jsonBody,
                                                                                                )?.toList() ??
                                                                                                [];

                                                                                            return ListView.builder(
                                                                                              padding: EdgeInsets.zero,
                                                                                              primary: false,
                                                                                              shrinkWrap: true,
                                                                                              scrollDirection: Axis.vertical,
                                                                                              itemCount: topicid.length,
                                                                                              itemBuilder: (context, topicidIndex) {
                                                                                                final topicidItem = topicid[topicidIndex];
                                                                                                return Padding(
                                                                                                  padding: EdgeInsets.all(4.0),
                                                                                                  child: FutureBuilder<List<TopicsRow>>(
                                                                                                    future: TopicsTable().querySingleRow(
                                                                                                      queryFn: (q) => q.eq(
                                                                                                        'id',
                                                                                                        topicidItem,
                                                                                                      ),
                                                                                                    ),
                                                                                                    builder: (context, snapshot) {
                                                                                                      // Customize what your widget looks like when it's loading.
                                                                                                      if (!snapshot.hasData) {
                                                                                                        return Center(
                                                                                                          child: SizedBox(
                                                                                                            width: 50.0,
                                                                                                            height: 50.0,
                                                                                                            child: CircularProgressIndicator(
                                                                                                              valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                                FlutterFlowTheme.of(context).primary,
                                                                                                              ),
                                                                                                            ),
                                                                                                          ),
                                                                                                        );
                                                                                                      }
                                                                                                      List<TopicsRow> containerTopicsRowList = snapshot.data!;

                                                                                                      final containerTopicsRow = containerTopicsRowList.isNotEmpty ? containerTopicsRowList.first : null;

                                                                                                      return Container(
                                                                                                        width: 100.0,
                                                                                                        height: 100.0,
                                                                                                        decoration: BoxDecoration(
                                                                                                          color: FlutterFlowTheme.of(context).secondaryBackground,
                                                                                                          borderRadius: BorderRadius.circular(8.0),
                                                                                                        ),
                                                                                                        child: InkWell(
                                                                                                          splashColor: Colors.transparent,
                                                                                                          focusColor: Colors.transparent,
                                                                                                          hoverColor: Colors.transparent,
                                                                                                          highlightColor: Colors.transparent,
                                                                                                          onTap: () async {
                                                                                                            context.pushNamed(
                                                                                                              'TopicsPage',
                                                                                                              queryParameters: {
                                                                                                                'topicId': serializeParam(
                                                                                                                  containerTopicsRow?.id,
                                                                                                                  ParamType.String,
                                                                                                                ),
                                                                                                              }.withoutNulls,
                                                                                                              extra: <String, dynamic>{
                                                                                                                kTransitionInfoKey: TransitionInfo(
                                                                                                                  hasTransition: true,
                                                                                                                  transitionType: PageTransitionType.fade,
                                                                                                                  duration: Duration(milliseconds: 0),
                                                                                                                ),
                                                                                                              },
                                                                                                            );
                                                                                                          },
                                                                                                          child: Card(
                                                                                                            clipBehavior: Clip.antiAliasWithSaveLayer,
                                                                                                            color: FlutterFlowTheme.of(context).primaryBackground,
                                                                                                            elevation: 4.0,
                                                                                                            shape: RoundedRectangleBorder(
                                                                                                              borderRadius: BorderRadius.circular(8.0),
                                                                                                            ),
                                                                                                            child: Row(
                                                                                                              mainAxisSize: MainAxisSize.max,
                                                                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                                              children: [
                                                                                                                Expanded(
                                                                                                                  child: Stack(
                                                                                                                    children: [
                                                                                                                      Padding(
                                                                                                                        padding: EdgeInsetsDirectional.fromSTEB(8.0, 10.0, 0.0, 0.0),
                                                                                                                        child: Text(
                                                                                                                          valueOrDefault<String>(
                                                                                                                            containerTopicsRow?.title,
                                                                                                                            'topic',
                                                                                                                          ),
                                                                                                                          style: FlutterFlowTheme.of(context).titleLarge.override(
                                                                                                                                fontFamily: 'Inter',
                                                                                                                                fontSize: MediaQuery.sizeOf(context).width < 991.0 ? 14.0 : 18.0,
                                                                                                                                letterSpacing: 0.0,
                                                                                                                              ),
                                                                                                                        ),
                                                                                                                      ),
                                                                                                                      Align(
                                                                                                                        alignment: AlignmentDirectional(1.0, 1.0),
                                                                                                                        child: Padding(
                                                                                                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
                                                                                                                          child: FutureBuilder<List<VotesRow>>(
                                                                                                                            future: VotesTable().queryRows(
                                                                                                                              queryFn: (q) => q.eq(
                                                                                                                                'topic_id',
                                                                                                                                topicidItem,
                                                                                                                              ),
                                                                                                                            ),
                                                                                                                            builder: (context, snapshot) {
                                                                                                                              // Customize what your widget looks like when it's loading.
                                                                                                                              if (!snapshot.hasData) {
                                                                                                                                return Center(
                                                                                                                                  child: SizedBox(
                                                                                                                                    width: 50.0,
                                                                                                                                    height: 50.0,
                                                                                                                                    child: CircularProgressIndicator(
                                                                                                                                      valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                                                        FlutterFlowTheme.of(context).primary,
                                                                                                                                      ),
                                                                                                                                    ),
                                                                                                                                  ),
                                                                                                                                );
                                                                                                                              }
                                                                                                                              List<VotesRow> textVotesRowList = snapshot.data!;

                                                                                                                              return Text(
                                                                                                                                'Upvotes: ${textVotesRowList.length.toString()}',
                                                                                                                                style: FlutterFlowTheme.of(context).labelLarge.override(
                                                                                                                                      fontFamily: 'Inter',
                                                                                                                                      fontSize: 12.0,
                                                                                                                                      letterSpacing: 0.0,
                                                                                                                                    ),
                                                                                                                              );
                                                                                                                            },
                                                                                                                          ),
                                                                                                                        ),
                                                                                                                      ),
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                ),
                                                                                                                Stack(
                                                                                                                  children: [
                                                                                                                    FutureBuilder<List<FavoritesRow>>(
                                                                                                                      future: FavoritesTable().querySingleRow(
                                                                                                                        queryFn: (q) => q
                                                                                                                            .eq(
                                                                                                                              'user_id',
                                                                                                                              currentUserUid,
                                                                                                                            )
                                                                                                                            .eq(
                                                                                                                              'topic_id',
                                                                                                                              containerTopicsRow?.id,
                                                                                                                            ),
                                                                                                                      ),
                                                                                                                      builder: (context, snapshot) {
                                                                                                                        // Customize what your widget looks like when it's loading.
                                                                                                                        if (!snapshot.hasData) {
                                                                                                                          return Center(
                                                                                                                            child: SizedBox(
                                                                                                                              width: 50.0,
                                                                                                                              height: 50.0,
                                                                                                                              child: CircularProgressIndicator(
                                                                                                                                valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                                                  FlutterFlowTheme.of(context).primary,
                                                                                                                                ),
                                                                                                                              ),
                                                                                                                            ),
                                                                                                                          );
                                                                                                                        }
                                                                                                                        List<FavoritesRow> columnFavoritesRowList = snapshot.data!;

                                                                                                                        final columnFavoritesRow = columnFavoritesRowList.isNotEmpty ? columnFavoritesRowList.first : null;

                                                                                                                        return Column(
                                                                                                                          mainAxisSize: MainAxisSize.max,
                                                                                                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                                                          children: [
                                                                                                                            FutureBuilder<List<VotesRow>>(
                                                                                                                              future: VotesTable().querySingleRow(
                                                                                                                                queryFn: (q) => q
                                                                                                                                    .eq(
                                                                                                                                      'user_id',
                                                                                                                                      currentUserUid,
                                                                                                                                    )
                                                                                                                                    .eq(
                                                                                                                                      'topic_id',
                                                                                                                                      columnFavoritesRow?.id,
                                                                                                                                    ),
                                                                                                                              ),
                                                                                                                              builder: (context, snapshot) {
                                                                                                                                // Customize what your widget looks like when it's loading.
                                                                                                                                if (!snapshot.hasData) {
                                                                                                                                  return Center(
                                                                                                                                    child: SizedBox(
                                                                                                                                      width: 50.0,
                                                                                                                                      height: 50.0,
                                                                                                                                      child: CircularProgressIndicator(
                                                                                                                                        valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                                                          FlutterFlowTheme.of(context).primary,
                                                                                                                                        ),
                                                                                                                                      ),
                                                                                                                                    ),
                                                                                                                                  );
                                                                                                                                }
                                                                                                                                List<VotesRow> conditionalBuilderVotesRowList = snapshot.data!;

                                                                                                                                final conditionalBuilderVotesRow = conditionalBuilderVotesRowList.isNotEmpty ? conditionalBuilderVotesRowList.first : null;

                                                                                                                                return Builder(
                                                                                                                                  builder: (context) {
                                                                                                                                    if (conditionalBuilderVotesRow?.id != null && conditionalBuilderVotesRow?.id != '') {
                                                                                                                                      return Padding(
                                                                                                                                        padding: EdgeInsets.all(2.0),
                                                                                                                                        child: InkWell(
                                                                                                                                          splashColor: Colors.transparent,
                                                                                                                                          focusColor: Colors.transparent,
                                                                                                                                          hoverColor: Colors.transparent,
                                                                                                                                          highlightColor: Colors.transparent,
                                                                                                                                          onTap: () async {
                                                                                                                                            await VotesTable().delete(
                                                                                                                                              matchingRows: (rows) => rows
                                                                                                                                                  .eq(
                                                                                                                                                    'user_id',
                                                                                                                                                    currentUserUid,
                                                                                                                                                  )
                                                                                                                                                  .eq(
                                                                                                                                                    'topic_id',
                                                                                                                                                    topicidItem,
                                                                                                                                                  ),
                                                                                                                                            );
                                                                                                                                            await Future.delayed(const Duration(milliseconds: 100));
                                                                                                                                            safeSetState(() => _model.apiRequestCompleter1 = null);
                                                                                                                                          },
                                                                                                                                          child: Icon(
                                                                                                                                            Icons.arrow_circle_up,
                                                                                                                                            color: FlutterFlowTheme.of(context).secondary,
                                                                                                                                            size: 40.0,
                                                                                                                                          ),
                                                                                                                                        ),
                                                                                                                                      );
                                                                                                                                    } else {
                                                                                                                                      return FutureBuilder<List<UserInfosRow>>(
                                                                                                                                        future: UserInfosTable().querySingleRow(
                                                                                                                                          queryFn: (q) => q.eq(
                                                                                                                                            'user_id',
                                                                                                                                            currentUserUid,
                                                                                                                                          ),
                                                                                                                                        ),
                                                                                                                                        builder: (context, snapshot) {
                                                                                                                                          // Customize what your widget looks like when it's loading.
                                                                                                                                          if (!snapshot.hasData) {
                                                                                                                                            return Center(
                                                                                                                                              child: SizedBox(
                                                                                                                                                width: 50.0,
                                                                                                                                                height: 50.0,
                                                                                                                                                child: CircularProgressIndicator(
                                                                                                                                                  valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                                                                    FlutterFlowTheme.of(context).primary,
                                                                                                                                                  ),
                                                                                                                                                ),
                                                                                                                                              ),
                                                                                                                                            );
                                                                                                                                          }
                                                                                                                                          List<UserInfosRow> iconUserInfosRowList = snapshot.data!;

                                                                                                                                          final iconUserInfosRow = iconUserInfosRowList.isNotEmpty ? iconUserInfosRowList.first : null;

                                                                                                                                          return InkWell(
                                                                                                                                            splashColor: Colors.transparent,
                                                                                                                                            focusColor: Colors.transparent,
                                                                                                                                            hoverColor: Colors.transparent,
                                                                                                                                            highlightColor: Colors.transparent,
                                                                                                                                            onTap: () async {
                                                                                                                                              await VotesTable().insert({
                                                                                                                                                'user_id': currentUserUid,
                                                                                                                                                'topic_id': topicidItem,
                                                                                                                                                'created_at': supaSerialize<DateTime>(getCurrentTimestamp),
                                                                                                                                              });
                                                                                                                                              if (iconUserInfosRow?.userId != null && iconUserInfosRow?.userId != '') {
                                                                                                                                                await Future.delayed(const Duration(milliseconds: 100));
                                                                                                                                              } else {
                                                                                                                                                await showDialog(
                                                                                                                                                  context: context,
                                                                                                                                                  builder: (alertDialogContext) {
                                                                                                                                                    return AlertDialog(
                                                                                                                                                      title: Text('Uncompleted Profile!'),
                                                                                                                                                      content: Text('Please complete your profile to use app functions.'),
                                                                                                                                                      actions: [
                                                                                                                                                        TextButton(
                                                                                                                                                          onPressed: () => Navigator.pop(alertDialogContext),
                                                                                                                                                          child: Text('Ok'),
                                                                                                                                                        ),
                                                                                                                                                      ],
                                                                                                                                                    );
                                                                                                                                                  },
                                                                                                                                                );

                                                                                                                                                context.pushNamed('ProfilePage');
                                                                                                                                              }

                                                                                                                                              safeSetState(() => _model.apiRequestCompleter1 = null);
                                                                                                                                            },
                                                                                                                                            child: Icon(
                                                                                                                                              Icons.arrow_circle_up,
                                                                                                                                              color: FlutterFlowTheme.of(context).secondaryText,
                                                                                                                                              size: 40.0,
                                                                                                                                            ),
                                                                                                                                          );
                                                                                                                                        },
                                                                                                                                      );
                                                                                                                                    }
                                                                                                                                  },
                                                                                                                                );
                                                                                                                              },
                                                                                                                            ),
                                                                                                                            Builder(
                                                                                                                              builder: (context) {
                                                                                                                                if (columnFavoritesRow?.id != null && columnFavoritesRow?.id != '') {
                                                                                                                                  return Padding(
                                                                                                                                    padding: EdgeInsets.all(2.0),
                                                                                                                                    child: InkWell(
                                                                                                                                      splashColor: Colors.transparent,
                                                                                                                                      focusColor: Colors.transparent,
                                                                                                                                      hoverColor: Colors.transparent,
                                                                                                                                      highlightColor: Colors.transparent,
                                                                                                                                      onTap: () async {
                                                                                                                                        await FavoritesTable().delete(
                                                                                                                                          matchingRows: (rows) => rows
                                                                                                                                              .eq(
                                                                                                                                                'user_id',
                                                                                                                                                currentUserUid,
                                                                                                                                              )
                                                                                                                                              .eq(
                                                                                                                                                'topic_id',
                                                                                                                                                topicidItem,
                                                                                                                                              ),
                                                                                                                                        );
                                                                                                                                        await Future.delayed(const Duration(milliseconds: 100));
                                                                                                                                        safeSetState(() => _model.apiRequestCompleter1 = null);
                                                                                                                                      },
                                                                                                                                      child: Icon(
                                                                                                                                        Icons.favorite_border,
                                                                                                                                        color: FlutterFlowTheme.of(context).error,
                                                                                                                                        size: 40.0,
                                                                                                                                      ),
                                                                                                                                    ),
                                                                                                                                  );
                                                                                                                                } else {
                                                                                                                                  return InkWell(
                                                                                                                                    splashColor: Colors.transparent,
                                                                                                                                    focusColor: Colors.transparent,
                                                                                                                                    hoverColor: Colors.transparent,
                                                                                                                                    highlightColor: Colors.transparent,
                                                                                                                                    onTap: () async {
                                                                                                                                      await FavoritesTable().insert({
                                                                                                                                        'user_id': currentUserUid,
                                                                                                                                        'topic_id': topicidItem,
                                                                                                                                        'created_at': supaSerialize<DateTime>(getCurrentTimestamp),
                                                                                                                                      });
                                                                                                                                      await Future.delayed(const Duration(milliseconds: 100));
                                                                                                                                      safeSetState(() => _model.apiRequestCompleter1 = null);
                                                                                                                                    },
                                                                                                                                    child: Icon(
                                                                                                                                      Icons.favorite_border,
                                                                                                                                      color: FlutterFlowTheme.of(context).secondaryText,
                                                                                                                                      size: 40.0,
                                                                                                                                    ),
                                                                                                                                  );
                                                                                                                                }
                                                                                                                              },
                                                                                                                            ),
                                                                                                                          ],
                                                                                                                        );
                                                                                                                      },
                                                                                                                    ),
                                                                                                                  ],
                                                                                                                ),
                                                                                                              ],
                                                                                                            ),
                                                                                                          ),
                                                                                                        ),
                                                                                                      );
                                                                                                    },
                                                                                                  ),
                                                                                                );
                                                                                              },
                                                                                            );
                                                                                          },
                                                                                        );
                                                                                      },
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                  ],
                                                                ),
                                                              ).animateOnPageLoad(
                                                                  animationsMap[
                                                                      'containerOnPageLoadAnimation1']!),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  if (responsiveVisibility(
                                                    context: context,
                                                    phone: false,
                                                    tablet: false,
                                                  ))
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  12.0,
                                                                  2.0,
                                                                  15.0,
                                                                  0.0),
                                                      child: Container(
                                                        width: 455.0,
                                                        height: 505.0,
                                                        constraints:
                                                            BoxConstraints(
                                                          maxWidth: 770.0,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .accent1,
                                                          boxShadow: [
                                                            BoxShadow(
                                                              blurRadius: 12.0,
                                                              color: Color(
                                                                  0x1E000000),
                                                              offset: Offset(
                                                                0.0,
                                                                5.0,
                                                              ),
                                                            )
                                                          ],
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      16.0),
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                              height: 65.0,
                                                              child: Stack(
                                                                children: [
                                                                  Align(
                                                                    alignment:
                                                                        AlignmentDirectional(
                                                                            0.0,
                                                                            0.0),
                                                                    child: Text(
                                                                      'New Topics',
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Inter',
                                                                            fontSize:
                                                                                22.0,
                                                                            letterSpacing:
                                                                                0.0,
                                                                            fontWeight:
                                                                                FontWeight.w600,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            if (responsiveVisibility(
                                                              context: context,
                                                              phone: false,
                                                            ))
                                                              Expanded(
                                                                child: Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          1.0),
                                                                  child:
                                                                      ClipRRect(
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .only(
                                                                      bottomLeft:
                                                                          Radius.circular(
                                                                              15.0),
                                                                      bottomRight:
                                                                          Radius.circular(
                                                                              15.0),
                                                                      topLeft: Radius
                                                                          .circular(
                                                                              0.0),
                                                                      topRight:
                                                                          Radius.circular(
                                                                              0.0),
                                                                    ),
                                                                    child:
                                                                        Container(
                                                                      width: double
                                                                          .infinity,
                                                                      height:
                                                                          505.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .secondaryBackground,
                                                                        borderRadius:
                                                                            BorderRadius.only(
                                                                          bottomLeft:
                                                                              Radius.circular(15.0),
                                                                          bottomRight:
                                                                              Radius.circular(15.0),
                                                                          topLeft:
                                                                              Radius.circular(0.0),
                                                                          topRight:
                                                                              Radius.circular(0.0),
                                                                        ),
                                                                      ),
                                                                      child:
                                                                          SingleChildScrollView(
                                                                        child:
                                                                            Column(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          children: [
                                                                            FutureBuilder<ApiCallResponse>(
                                                                              future: (_model.apiRequestCompleter2 ??= Completer<ApiCallResponse>()
                                                                                    ..complete(SearchOnTopicsCall.call(
                                                                                      searchTerm: '',
                                                                                    )))
                                                                                  .future,
                                                                              builder: (context, snapshot) {
                                                                                // Customize what your widget looks like when it's loading.
                                                                                if (!snapshot.hasData) {
                                                                                  return Center(
                                                                                    child: SizedBox(
                                                                                      width: 50.0,
                                                                                      height: 50.0,
                                                                                      child: CircularProgressIndicator(
                                                                                        valueColor: AlwaysStoppedAnimation<Color>(
                                                                                          FlutterFlowTheme.of(context).primary,
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  );
                                                                                }
                                                                                final listViewSearchOnTopicsResponse = snapshot.data!;

                                                                                return Builder(
                                                                                  builder: (context) {
                                                                                    final topicid = SearchOnTopicsCall.topicid(
                                                                                          listViewSearchOnTopicsResponse.jsonBody,
                                                                                        )?.toList() ??
                                                                                        [];

                                                                                    return ListView.builder(
                                                                                      padding: EdgeInsets.zero,
                                                                                      reverse: true,
                                                                                      primary: false,
                                                                                      shrinkWrap: true,
                                                                                      scrollDirection: Axis.vertical,
                                                                                      itemCount: topicid.length,
                                                                                      itemBuilder: (context, topicidIndex) {
                                                                                        final topicidItem = topicid[topicidIndex];
                                                                                        return Padding(
                                                                                          padding: EdgeInsets.all(4.0),
                                                                                          child: FutureBuilder<List<TopicsRow>>(
                                                                                            future: TopicsTable().querySingleRow(
                                                                                              queryFn: (q) => q.eq(
                                                                                                'id',
                                                                                                topicidItem,
                                                                                              ),
                                                                                            ),
                                                                                            builder: (context, snapshot) {
                                                                                              // Customize what your widget looks like when it's loading.
                                                                                              if (!snapshot.hasData) {
                                                                                                return Center(
                                                                                                  child: SizedBox(
                                                                                                    width: 50.0,
                                                                                                    height: 50.0,
                                                                                                    child: CircularProgressIndicator(
                                                                                                      valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                        FlutterFlowTheme.of(context).primary,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ),
                                                                                                );
                                                                                              }
                                                                                              List<TopicsRow> containerTopicsRowList = snapshot.data!;

                                                                                              final containerTopicsRow = containerTopicsRowList.isNotEmpty ? containerTopicsRowList.first : null;

                                                                                              return Container(
                                                                                                width: 100.0,
                                                                                                height: 100.0,
                                                                                                decoration: BoxDecoration(
                                                                                                  color: FlutterFlowTheme.of(context).secondaryBackground,
                                                                                                  borderRadius: BorderRadius.circular(8.0),
                                                                                                ),
                                                                                                child: InkWell(
                                                                                                  splashColor: Colors.transparent,
                                                                                                  focusColor: Colors.transparent,
                                                                                                  hoverColor: Colors.transparent,
                                                                                                  highlightColor: Colors.transparent,
                                                                                                  onTap: () async {
                                                                                                    context.pushNamed(
                                                                                                      'TopicsPage',
                                                                                                      queryParameters: {
                                                                                                        'topicId': serializeParam(
                                                                                                          containerTopicsRow?.id,
                                                                                                          ParamType.String,
                                                                                                        ),
                                                                                                      }.withoutNulls,
                                                                                                      extra: <String, dynamic>{
                                                                                                        kTransitionInfoKey: TransitionInfo(
                                                                                                          hasTransition: true,
                                                                                                          transitionType: PageTransitionType.fade,
                                                                                                          duration: Duration(milliseconds: 0),
                                                                                                        ),
                                                                                                      },
                                                                                                    );
                                                                                                  },
                                                                                                  child: Card(
                                                                                                    clipBehavior: Clip.antiAliasWithSaveLayer,
                                                                                                    color: FlutterFlowTheme.of(context).primaryBackground,
                                                                                                    elevation: 4.0,
                                                                                                    shape: RoundedRectangleBorder(
                                                                                                      borderRadius: BorderRadius.circular(8.0),
                                                                                                    ),
                                                                                                    child: Row(
                                                                                                      mainAxisSize: MainAxisSize.max,
                                                                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                                      children: [
                                                                                                        Expanded(
                                                                                                          child: Stack(
                                                                                                            children: [
                                                                                                              Padding(
                                                                                                                padding: EdgeInsetsDirectional.fromSTEB(8.0, 10.0, 0.0, 0.0),
                                                                                                                child: Text(
                                                                                                                  valueOrDefault<String>(
                                                                                                                    containerTopicsRow?.title,
                                                                                                                    'topic',
                                                                                                                  ),
                                                                                                                  style: FlutterFlowTheme.of(context).titleLarge.override(
                                                                                                                        fontFamily: 'Inter',
                                                                                                                        fontSize: MediaQuery.sizeOf(context).width < 991.0 ? 14.0 : 18.0,
                                                                                                                        letterSpacing: 0.0,
                                                                                                                      ),
                                                                                                                ),
                                                                                                              ),
                                                                                                              Align(
                                                                                                                alignment: AlignmentDirectional(1.0, 1.0),
                                                                                                                child: Padding(
                                                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
                                                                                                                  child: FutureBuilder<List<VotesRow>>(
                                                                                                                    future: VotesTable().queryRows(
                                                                                                                      queryFn: (q) => q.eq(
                                                                                                                        'topic_id',
                                                                                                                        topicidItem,
                                                                                                                      ),
                                                                                                                    ),
                                                                                                                    builder: (context, snapshot) {
                                                                                                                      // Customize what your widget looks like when it's loading.
                                                                                                                      if (!snapshot.hasData) {
                                                                                                                        return Center(
                                                                                                                          child: SizedBox(
                                                                                                                            width: 50.0,
                                                                                                                            height: 50.0,
                                                                                                                            child: CircularProgressIndicator(
                                                                                                                              valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                                                FlutterFlowTheme.of(context).primary,
                                                                                                                              ),
                                                                                                                            ),
                                                                                                                          ),
                                                                                                                        );
                                                                                                                      }
                                                                                                                      List<VotesRow> textVotesRowList = snapshot.data!;

                                                                                                                      return Text(
                                                                                                                        'Upvotes: ${textVotesRowList.length.toString()}',
                                                                                                                        style: FlutterFlowTheme.of(context).labelLarge.override(
                                                                                                                              fontFamily: 'Inter',
                                                                                                                              fontSize: 12.0,
                                                                                                                              letterSpacing: 0.0,
                                                                                                                            ),
                                                                                                                      );
                                                                                                                    },
                                                                                                                  ),
                                                                                                                ),
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                        ),
                                                                                                        Stack(
                                                                                                          children: [
                                                                                                            FutureBuilder<List<FavoritesRow>>(
                                                                                                              future: FavoritesTable().querySingleRow(
                                                                                                                queryFn: (q) => q
                                                                                                                    .eq(
                                                                                                                      'user_id',
                                                                                                                      currentUserUid,
                                                                                                                    )
                                                                                                                    .eq(
                                                                                                                      'topic_id',
                                                                                                                      containerTopicsRow?.id,
                                                                                                                    ),
                                                                                                              ),
                                                                                                              builder: (context, snapshot) {
                                                                                                                // Customize what your widget looks like when it's loading.
                                                                                                                if (!snapshot.hasData) {
                                                                                                                  return Center(
                                                                                                                    child: SizedBox(
                                                                                                                      width: 50.0,
                                                                                                                      height: 50.0,
                                                                                                                      child: CircularProgressIndicator(
                                                                                                                        valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                                          FlutterFlowTheme.of(context).primary,
                                                                                                                        ),
                                                                                                                      ),
                                                                                                                    ),
                                                                                                                  );
                                                                                                                }
                                                                                                                List<FavoritesRow> columnFavoritesRowList = snapshot.data!;

                                                                                                                final columnFavoritesRow = columnFavoritesRowList.isNotEmpty ? columnFavoritesRowList.first : null;

                                                                                                                return Column(
                                                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                                                  children: [
                                                                                                                    FutureBuilder<List<VotesRow>>(
                                                                                                                      future: VotesTable().querySingleRow(
                                                                                                                        queryFn: (q) => q
                                                                                                                            .eq(
                                                                                                                              'user_id',
                                                                                                                              currentUserUid,
                                                                                                                            )
                                                                                                                            .eq(
                                                                                                                              'topic_id',
                                                                                                                              columnFavoritesRow?.id,
                                                                                                                            ),
                                                                                                                      ),
                                                                                                                      builder: (context, snapshot) {
                                                                                                                        // Customize what your widget looks like when it's loading.
                                                                                                                        if (!snapshot.hasData) {
                                                                                                                          return Center(
                                                                                                                            child: SizedBox(
                                                                                                                              width: 50.0,
                                                                                                                              height: 50.0,
                                                                                                                              child: CircularProgressIndicator(
                                                                                                                                valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                                                  FlutterFlowTheme.of(context).primary,
                                                                                                                                ),
                                                                                                                              ),
                                                                                                                            ),
                                                                                                                          );
                                                                                                                        }
                                                                                                                        List<VotesRow> conditionalBuilderVotesRowList = snapshot.data!;

                                                                                                                        final conditionalBuilderVotesRow = conditionalBuilderVotesRowList.isNotEmpty ? conditionalBuilderVotesRowList.first : null;

                                                                                                                        return Builder(
                                                                                                                          builder: (context) {
                                                                                                                            if (conditionalBuilderVotesRow?.id != null && conditionalBuilderVotesRow?.id != '') {
                                                                                                                              return Padding(
                                                                                                                                padding: EdgeInsets.all(2.0),
                                                                                                                                child: InkWell(
                                                                                                                                  splashColor: Colors.transparent,
                                                                                                                                  focusColor: Colors.transparent,
                                                                                                                                  hoverColor: Colors.transparent,
                                                                                                                                  highlightColor: Colors.transparent,
                                                                                                                                  onTap: () async {
                                                                                                                                    await VotesTable().delete(
                                                                                                                                      matchingRows: (rows) => rows
                                                                                                                                          .eq(
                                                                                                                                            'user_id',
                                                                                                                                            currentUserUid,
                                                                                                                                          )
                                                                                                                                          .eq(
                                                                                                                                            'topic_id',
                                                                                                                                            topicidItem,
                                                                                                                                          ),
                                                                                                                                    );
                                                                                                                                    await Future.delayed(const Duration(milliseconds: 100));
                                                                                                                                    safeSetState(() => _model.apiRequestCompleter2 = null);
                                                                                                                                  },
                                                                                                                                  child: Icon(
                                                                                                                                    Icons.arrow_circle_up,
                                                                                                                                    color: FlutterFlowTheme.of(context).secondary,
                                                                                                                                    size: 40.0,
                                                                                                                                  ),
                                                                                                                                ),
                                                                                                                              );
                                                                                                                            } else {
                                                                                                                              return FutureBuilder<List<UserInfosRow>>(
                                                                                                                                future: UserInfosTable().querySingleRow(
                                                                                                                                  queryFn: (q) => q.eq(
                                                                                                                                    'user_id',
                                                                                                                                    currentUserUid,
                                                                                                                                  ),
                                                                                                                                ),
                                                                                                                                builder: (context, snapshot) {
                                                                                                                                  // Customize what your widget looks like when it's loading.
                                                                                                                                  if (!snapshot.hasData) {
                                                                                                                                    return Center(
                                                                                                                                      child: SizedBox(
                                                                                                                                        width: 50.0,
                                                                                                                                        height: 50.0,
                                                                                                                                        child: CircularProgressIndicator(
                                                                                                                                          valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                                                            FlutterFlowTheme.of(context).primary,
                                                                                                                                          ),
                                                                                                                                        ),
                                                                                                                                      ),
                                                                                                                                    );
                                                                                                                                  }
                                                                                                                                  List<UserInfosRow> iconUserInfosRowList = snapshot.data!;

                                                                                                                                  final iconUserInfosRow = iconUserInfosRowList.isNotEmpty ? iconUserInfosRowList.first : null;

                                                                                                                                  return InkWell(
                                                                                                                                    splashColor: Colors.transparent,
                                                                                                                                    focusColor: Colors.transparent,
                                                                                                                                    hoverColor: Colors.transparent,
                                                                                                                                    highlightColor: Colors.transparent,
                                                                                                                                    onTap: () async {
                                                                                                                                      await VotesTable().insert({
                                                                                                                                        'user_id': currentUserUid,
                                                                                                                                        'topic_id': topicidItem,
                                                                                                                                        'created_at': supaSerialize<DateTime>(getCurrentTimestamp),
                                                                                                                                      });
                                                                                                                                      if (iconUserInfosRow?.userId != null && iconUserInfosRow?.userId != '') {
                                                                                                                                        await Future.delayed(const Duration(milliseconds: 100));
                                                                                                                                      } else {
                                                                                                                                        await showDialog(
                                                                                                                                          context: context,
                                                                                                                                          builder: (alertDialogContext) {
                                                                                                                                            return AlertDialog(
                                                                                                                                              title: Text('Uncompleted Profile!'),
                                                                                                                                              content: Text('Please complete your profile to use app functions.'),
                                                                                                                                              actions: [
                                                                                                                                                TextButton(
                                                                                                                                                  onPressed: () => Navigator.pop(alertDialogContext),
                                                                                                                                                  child: Text('Ok'),
                                                                                                                                                ),
                                                                                                                                              ],
                                                                                                                                            );
                                                                                                                                          },
                                                                                                                                        );

                                                                                                                                        context.pushNamed('ProfilePage');
                                                                                                                                      }

                                                                                                                                      safeSetState(() => _model.apiRequestCompleter2 = null);
                                                                                                                                    },
                                                                                                                                    child: Icon(
                                                                                                                                      Icons.arrow_circle_up,
                                                                                                                                      color: FlutterFlowTheme.of(context).secondaryText,
                                                                                                                                      size: 40.0,
                                                                                                                                    ),
                                                                                                                                  );
                                                                                                                                },
                                                                                                                              );
                                                                                                                            }
                                                                                                                          },
                                                                                                                        );
                                                                                                                      },
                                                                                                                    ),
                                                                                                                    Builder(
                                                                                                                      builder: (context) {
                                                                                                                        if (columnFavoritesRow?.id != null && columnFavoritesRow?.id != '') {
                                                                                                                          return Padding(
                                                                                                                            padding: EdgeInsets.all(2.0),
                                                                                                                            child: InkWell(
                                                                                                                              splashColor: Colors.transparent,
                                                                                                                              focusColor: Colors.transparent,
                                                                                                                              hoverColor: Colors.transparent,
                                                                                                                              highlightColor: Colors.transparent,
                                                                                                                              onTap: () async {
                                                                                                                                await FavoritesTable().delete(
                                                                                                                                  matchingRows: (rows) => rows
                                                                                                                                      .eq(
                                                                                                                                        'user_id',
                                                                                                                                        currentUserUid,
                                                                                                                                      )
                                                                                                                                      .eq(
                                                                                                                                        'topic_id',
                                                                                                                                        topicidItem,
                                                                                                                                      ),
                                                                                                                                );
                                                                                                                                await Future.delayed(const Duration(milliseconds: 100));
                                                                                                                                safeSetState(() => _model.apiRequestCompleter2 = null);
                                                                                                                              },
                                                                                                                              child: Icon(
                                                                                                                                Icons.favorite_border,
                                                                                                                                color: FlutterFlowTheme.of(context).error,
                                                                                                                                size: 40.0,
                                                                                                                              ),
                                                                                                                            ),
                                                                                                                          );
                                                                                                                        } else {
                                                                                                                          return InkWell(
                                                                                                                            splashColor: Colors.transparent,
                                                                                                                            focusColor: Colors.transparent,
                                                                                                                            hoverColor: Colors.transparent,
                                                                                                                            highlightColor: Colors.transparent,
                                                                                                                            onTap: () async {
                                                                                                                              await FavoritesTable().insert({
                                                                                                                                'user_id': currentUserUid,
                                                                                                                                'topic_id': topicidItem,
                                                                                                                                'created_at': supaSerialize<DateTime>(getCurrentTimestamp),
                                                                                                                              });
                                                                                                                              await Future.delayed(const Duration(milliseconds: 100));
                                                                                                                              safeSetState(() => _model.apiRequestCompleter2 = null);
                                                                                                                            },
                                                                                                                            child: Icon(
                                                                                                                              Icons.favorite_border,
                                                                                                                              color: FlutterFlowTheme.of(context).secondaryText,
                                                                                                                              size: 40.0,
                                                                                                                            ),
                                                                                                                          );
                                                                                                                        }
                                                                                                                      },
                                                                                                                    ),
                                                                                                                  ],
                                                                                                                );
                                                                                                              },
                                                                                                            ),
                                                                                                          ],
                                                                                                        ),
                                                                                                      ],
                                                                                                    ),
                                                                                                  ),
                                                                                                ),
                                                                                              );
                                                                                            },
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    );
                                                                                  },
                                                                                );
                                                                              },
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                          ],
                                                        ),
                                                      ).animateOnPageLoad(
                                                          animationsMap[
                                                              'containerOnPageLoadAnimation2']!),
                                                    ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
