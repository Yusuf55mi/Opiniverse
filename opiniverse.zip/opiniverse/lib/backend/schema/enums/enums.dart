import 'package:collection/collection.dart';

enum ListType {
  Topic,
  Opinion,
  Comment,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (ListType):
      return ListType.values.deserialize(value) as T?;
    default:
      return null;
  }
}
