import '../database.dart';

class OpinionsTable extends SupabaseTable<OpinionsRow> {
  @override
  String get tableName => 'opinions';

  @override
  OpinionsRow createRow(Map<String, dynamic> data) => OpinionsRow(data);
}

class OpinionsRow extends SupabaseDataRow {
  OpinionsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => OpinionsTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String? get topicId => getField<String>('topic_id');
  set topicId(String? value) => setField<String>('topic_id', value);

  String? get userId => getField<String>('user_id');
  set userId(String? value) => setField<String>('user_id', value);

  String get content => getField<String>('content')!;
  set content(String value) => setField<String>('content', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  bool get isSupporting => getField<bool>('is_supporting')!;
  set isSupporting(bool value) => setField<bool>('is_supporting', value);

  int? get upvotes => getField<int>('upvotes');
  set upvotes(int? value) => setField<int>('upvotes', value);

  String? get createdBy => getField<String>('createdBy');
  set createdBy(String? value) => setField<String>('createdBy', value);
}
