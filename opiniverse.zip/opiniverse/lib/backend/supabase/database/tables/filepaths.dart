import '../database.dart';

class FilepathsTable extends SupabaseTable<FilepathsRow> {
  @override
  String get tableName => 'filepaths';

  @override
  FilepathsRow createRow(Map<String, dynamic> data) => FilepathsRow(data);
}

class FilepathsRow extends SupabaseDataRow {
  FilepathsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => FilepathsTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String get contentId => getField<String>('content_id')!;
  set contentId(String value) => setField<String>('content_id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String get filePath => getField<String>('file_path')!;
  set filePath(String value) => setField<String>('file_path', value);
}
