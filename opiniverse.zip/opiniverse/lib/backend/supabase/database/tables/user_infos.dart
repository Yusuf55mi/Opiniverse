import '../database.dart';

class UserInfosTable extends SupabaseTable<UserInfosRow> {
  @override
  String get tableName => 'user_infos';

  @override
  UserInfosRow createRow(Map<String, dynamic> data) => UserInfosRow(data);
}

class UserInfosRow extends SupabaseDataRow {
  UserInfosRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => UserInfosTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String get userMail => getField<String>('user_mail')!;
  set userMail(String value) => setField<String>('user_mail', value);

  String? get userId => getField<String>('user_id');
  set userId(String? value) => setField<String>('user_id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get nickName => getField<String>('nickName');
  set nickName(String? value) => setField<String>('nickName', value);

  String? get nameSurname => getField<String>('nameSurname');
  set nameSurname(String? value) => setField<String>('nameSurname', value);
}
