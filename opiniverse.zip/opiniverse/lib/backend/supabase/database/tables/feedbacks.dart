import '../database.dart';

class FeedbacksTable extends SupabaseTable<FeedbacksRow> {
  @override
  String get tableName => 'feedbacks';

  @override
  FeedbacksRow createRow(Map<String, dynamic> data) => FeedbacksRow(data);
}

class FeedbacksRow extends SupabaseDataRow {
  FeedbacksRow(super.data);

  @override
  SupabaseTable get table => FeedbacksTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String get userId => getField<String>('user_id')!;
  set userId(String value) => setField<String>('user_id', value);

  String? get topicId => getField<String>('topic_id');
  set topicId(String? value) => setField<String>('topic_id', value);

  String? get opinionId => getField<String>('opinion_id');
  set opinionId(String? value) => setField<String>('opinion_id', value);

  String? get commentId => getField<String>('comment_id');
  set commentId(String? value) => setField<String>('comment_id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String get feedbackType => getField<String>('feedback_type')!;
  set feedbackType(String value) => setField<String>('feedback_type', value);

  String get feedback => getField<String>('feedback')!;
  set feedback(String value) => setField<String>('feedback', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);

  String? get operationComment => getField<String>('operation_comment');
  set operationComment(String? value) =>
      setField<String>('operation_comment', value);
}
