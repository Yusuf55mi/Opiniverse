import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'sheet_simple_widget.dart' show SheetSimpleWidget;
import 'package:flutter/material.dart';

class SheetSimpleModel extends FlutterFlowModel<SheetSimpleWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  // State field(s) for oneTimePass widget.
  FocusNode? oneTimePassFocusNode;
  TextEditingController? oneTimePassTextController;
  late bool oneTimePassVisibility;
  String? Function(BuildContext, String?)? oneTimePassTextControllerValidator;
  // Stores action output result for [Backend Call - API (otpsignin)] action in Button widget.
  ApiCallResponse? apiResultp3f;

  @override
  void initState(BuildContext context) {
    oneTimePassVisibility = false;
  }

  @override
  void dispose() {
    emailFocusNode?.dispose();
    emailTextController?.dispose();

    oneTimePassFocusNode?.dispose();
    oneTimePassTextController?.dispose();
  }
}
