package com.multicode.opiniverse

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
